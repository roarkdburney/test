#ifndef DATE_H
#define DATE_H

using namespace std;

class date
{
  public:
    int day,month,year;
};

#endif
